﻿using UnityEngine;
using UnityEngine.Events;
using System;
using System.Collections;
using System.Collections.Generic;
public class SvrManager : MonoBehaviour
{
    static public int EyeLayerMax = 8;  // svrApi SVR_MAX_EYE_LAYERS
    static public int OverlayLayerMax = 8;  // svrApi SVR_MAX_OVERLAY_LAYERS

    [Serializable]
    public class SvrSettings
    { 
        public enum eAntiAliasing
        {
            k1 = 1,
            k2 = 2,
            k4 = 4,
        };
		
        public enum eDepth
        {
            k16 = 16,
            k24 = 24
        };
		
        public enum eChromaticAberrationCorrection
        {
            kDisable = 0,
            kEnable = 1
        };
		
        public enum eVSyncCount
        {
            k1 = 1,
            k2 = 2,
        };
		
        public enum eMasterTextureLimit
        {
            k0 = 0, // full size
            k1 = 1, // half size
            k2 = 2, // quarter size
            k3 = 3, // ...
            k4 = 4  // ...
        };
		
        public enum ePerfLevel
        { 
            System = 0,
            Minimum = 1,
            Medium = 2,
            Maximum = 3
        };
		
        public bool trackPosition = false;
        public float trackPositionScale = 1;
        public float headHeight = 0.0750f;
        public float headDepth = 0.0805f;
        public float interPupilDistance = 0.064f;
        public float eyeResolutionScaleFactor = 1.0f;
        public eDepth eyeDepth = eDepth.k24;
        public eAntiAliasing eyeAntiAliasing = eAntiAliasing.k2;
        public bool eyeHdr = false;
        public eDepth overlayDepth = eDepth.k16;
        public float overlayResolutionScaleFactor = 1.0f;
        public eAntiAliasing overlayAntiAliasing = eAntiAliasing.k1;
        public bool overlayHdr = false;
        public eVSyncCount vSyncCount = eVSyncCount.k1;
        public eChromaticAberrationCorrection chromaticAberationCorrection = eChromaticAberrationCorrection.kEnable;
        public eMasterTextureLimit masterTextureLimit = eMasterTextureLimit.k0;
        public ePerfLevel cpuPerfLevel = ePerfLevel.Medium;
        public ePerfLevel gpuPerfLevel = ePerfLevel.Medium;
    }
	
    [SerializeField]
    private SvrSettings settings;	
    public Transform head;
    public Camera monoCamera;
    public Camera leftCamera;
    public Camera rightCamera;
    public Camera leftOverlay;
    public Camera rightOverlay;
    public Camera monoOverlay;
	
    private int	frameCount = 0;
	private static WaitForEndOfFrame waitForEndOfFrame = new WaitForEndOfFrame();
	private SvrPlugin plugin = null;
    private float sensorWarmupDuration = 1.0f;
    private bool initialized = false;
    private bool running = false;
    private List<SvrEye> eyes = new List<SvrEye>(EyeLayerMax);
	private List<SvrOverlay> overlays = new List<SvrOverlay>(OverlayLayerMax);
    private bool disableInput = false;
    private Coroutine onResume = null;

    public bool Initialized
    {
        get { return initialized; }
    }

    public bool IsRunning
    {
        get { return running; }
    }

    public bool DisableInput
    {
        get { return disableInput; }
        set { disableInput = value; }
    }

	void Awake()
	{
		if (!ValidateReferencedComponents ())
		{
			enabled = false;
			return;
		}
        RegisterListeners();
        Input.backButtonLeavesApp = true;
        Application.targetFrameRate = -1;
    }
	
bool ValidateReferencedComponents()
	{
		plugin = SvrPlugin.Instance;
		if(plugin == null)
		{
			Debug.LogError("Svr Plugin failed to load. Disabling...");
			return false;
		}

		if(head == null)
		{
			Debug.LogError("Required head gameobject not found! Disabling...");
			return false;
		}

		if(monoCamera == null && (leftCamera == null || rightCamera == null))
		{
			Debug.LogError("Required eye components are missing! Disabling...");
			return false;
		}

		return true;
	}

	// Use this for initialization
	IEnumerator Start ()
	{
		yield return StartCoroutine(Initialize());
        initialized = plugin.IsInitialized();
        yield return StartCoroutine(plugin.BeginVr((int)settings.cpuPerfLevel, (int)settings.gpuPerfLevel));

        StartCoroutine(SubmitFrame());

        // Give the sensors a second to get ready
        yield return new WaitForSecondsRealtime(sensorWarmupDuration);

		plugin.RecenterTracking();
        running = plugin.IsRunning();

        Debug.Log("Svr initialized!");
	}

	private IEnumerator Initialize()
	{
		// Plugin must be initialized OnStart in order to properly
		// get a valid surface
        GameObject mainCameraGo = GameObject.FindWithTag("MainCamera");
        if (mainCameraGo)
        {
            mainCameraGo.SetActive(false);

            Debug.Log("Camera with MainCamera tag found.");
            if (!disableInput)
            {
                Debug.Log("Will use translation and orientation from the MainCamera.");
                transform.position = mainCameraGo.transform.position;
                transform.rotation = mainCameraGo.transform.rotation;
            }

            Debug.Log("Disabling Camera with MainCamera tag");
        }

        GL.Clear(false, true, Color.black);

		yield return StartCoroutine(plugin.Initialize());
		InitializeEyes();
        InitializeOverlays();

        if (settings.trackPosition)
        {
            plugin.SetTrackingMode(SvrPlugin.TrackingMode.kTrackingPosition);
        }
        else
        {
            plugin.SetTrackingMode(SvrPlugin.TrackingMode.kTrackingOrientation);
        }

        plugin.SetVSyncCount((int)settings.vSyncCount);
        QualitySettings.vSyncCount = (int)settings.vSyncCount;
	}
    
    private void AddEyes(Camera cam, SvrEye.eSide side)
    {
        bool enableCamera = false;
        var eyesFound = cam.gameObject.GetComponents<SvrEye>();
        for (int i = 0; i < eyesFound.Length; i++)
        {
            eyesFound[i].Side = side;
            if (eyesFound[i].imageType == SvrEye.eType.RenderTexture) enableCamera = true;
        }
        eyes.AddRange(eyesFound);
        if (eyesFound.Length == 0)
        {
            var eye = cam.gameObject.AddComponent<SvrEye>();
            eye.Side = side;
            eyes.Add(eye);
            enableCamera = true;
        }
        cam.hdr = settings.eyeHdr;
        cam.enabled = enableCamera;
    }

	private void InitializeEyes()
	{
        eyes.Clear();
        if (monoCamera != null && monoCamera.gameObject.activeSelf)
        {
            AddEyes(monoCamera, SvrEye.eSide.Both);
        }
        if (leftCamera != null && leftCamera.gameObject.activeSelf)
        {
            AddEyes(leftCamera, SvrEye.eSide.Left);
        }
        if (rightCamera != null && rightCamera.gameObject.activeSelf)
        {
            AddEyes(rightCamera, SvrEye.eSide.Right);
        }

        if (settings.eyeHdr && settings.eyeAntiAliasing != SvrSettings.eAntiAliasing.k1)
		{
			Debug.LogWarning("Antialiasing not supported when HDR is enabled. Disabling antiAliasing...");
			settings.eyeAntiAliasing = SvrSettings.eAntiAliasing.k1;
		}

        SvrPlugin.DeviceInfo info = plugin.deviceInfo;

		foreach(SvrEye eye in eyes)
		{
            if (eye == null) continue;

			Vector3 eyePos;
			eyePos.x = (eye.Side == SvrEye.eSide.Both ? 0f : (eye.Side == SvrEye.eSide.Left ? -0.5f : 0.5f) * settings.interPupilDistance);
			eyePos.y = (!settings.trackPosition ? settings.headHeight : 0);
			eyePos.z = (!settings.trackPosition ? -settings.headDepth : 0);
            eyePos += head.transform.localPosition;

            eye.transform.localPosition = eyePos;
			eye.Format					= settings.eyeHdr ? RenderTextureFormat.DefaultHDR : RenderTextureFormat.Default;
			eye.Resolution  			= new Vector2(info.targetEyeWidthPixels, info.targetEyeHeightPixels);
			eye.Depth 					= (int)settings.eyeDepth;
			eye.AntiAliasing 			= (int)settings.eyeAntiAliasing;	// hdr not supported with antialiasing
            eye.OnPostRenderListener 	= OnPostRenderListener;

            eye.Initialize();
		}
	}

    private void AddOverlays(Camera cam, SvrOverlay.eSide side)
    {
        bool enableCamera = false;
        var overlaysFound = cam.gameObject.GetComponents<SvrOverlay>();
        for (int i = 0; i < overlaysFound.Length; i++)
        {
            overlaysFound[i].Side = side;
            if (overlaysFound[i].imageType == SvrOverlay.eType.RenderTexture) enableCamera = true;
        }
        overlays.AddRange(overlaysFound);
        if (overlaysFound.Length == 0)
        {
            var overlay = cam.gameObject.AddComponent<SvrOverlay>();
            overlay.Side = side;
            overlays.Add(overlay);
            enableCamera = true;
        }
        cam.hdr = settings.overlayHdr;
        cam.enabled = enableCamera;
    }

    void InitializeOverlays()
    {
        overlays.Clear();
        if (leftOverlay != null && leftOverlay.gameObject.activeSelf)
        {
            AddOverlays(leftOverlay, SvrOverlay.eSide.Left);
        }
        if (rightOverlay != null && rightOverlay.gameObject.activeSelf)
        {
            AddOverlays(rightOverlay, SvrOverlay.eSide.Right);
        }
        if (monoOverlay != null && monoOverlay.gameObject.activeSelf)
        {
            AddOverlays(monoOverlay, SvrOverlay.eSide.Both);
        }
        if (settings.overlayHdr && settings.overlayAntiAliasing != SvrSettings.eAntiAliasing.k1)
        {
            Debug.LogWarning("Antialiasing not supported when HDR is enabled. Disabling antiAliasing...");
            settings.overlayAntiAliasing = SvrSettings.eAntiAliasing.k1;
        }

        SvrPlugin.DeviceInfo info = plugin.deviceInfo;

        foreach (SvrOverlay overlay in overlays)
        {
            if (overlay == null) continue;

            Vector3 eyePos;
            eyePos.x = (overlay.Side == SvrOverlay.eSide.Both ? 0f : (overlay.Side == SvrOverlay.eSide.Left ? -0.5f : 0.5f) * settings.interPupilDistance);
            eyePos.y = (!settings.trackPosition ? settings.headHeight : 0);
            eyePos.z = (!settings.trackPosition ? -settings.headDepth : 0);
            eyePos += head.transform.localPosition;

            overlay.transform.localPosition = eyePos;
            overlay.Format = settings.overlayHdr ? RenderTextureFormat.DefaultHDR : RenderTextureFormat.Default;
            overlay.Resolution = new Vector2(info.targetEyeWidthPixels, info.targetEyeHeightPixels);
            overlay.Depth = (int)settings.overlayDepth;
            overlay.AntiAliasing = (int)settings.overlayAntiAliasing;  // hdr not supported with antialiasing
            overlay.OnPostRenderListener = OnPostRenderListener;

            overlay.Initialize();
        }
    }

    IEnumerator SubmitFrame ()
	{
		while(true)
		{
			yield return waitForEndOfFrame;

			var eyeFieldOfView = leftCamera.fieldOfView * Mathf.Deg2Rad;

            plugin.SubmitFrame(frameCount, eyeFieldOfView);
			
			frameCount++;
		}
	}
	
	public void RecenterTracking()
	{
		plugin.RecenterTracking();
	}

	void OnPostRenderListener ()
	{
		plugin.EndEye ();
	}

    public void SetPause(bool pause)
	{
        if (!initialized || running != pause)
			return;

        if (pause)
		{
			OnPause();
		}
        else if (onResume == null)
        {
            onResume = StartCoroutine(OnResume());
		}
    }

    void OnPause()
	{
        running = false;
		StopAllCoroutines();
        plugin.EndVr ();
        onResume = null;
    }

    IEnumerator OnResume()
	{
        yield return StartCoroutine(plugin.BeginVr((int)settings.cpuPerfLevel, (int)settings.gpuPerfLevel));

		StartCoroutine (SubmitFrame ());

        // Give the sensors a second to get ready
        yield return new WaitForSecondsRealtime(sensorWarmupDuration);

        plugin.RecenterTracking();
        running = plugin.IsRunning();

        yield break;
	}

	void LateUpdate()
    {
        if (!initialized || !running)
        {
            return;
        }

        Vector3 position = new Vector3();
        Quaternion orientation = new Quaternion();
        plugin.GetPredictedPose(ref orientation, ref position, frameCount);

        if (!disableInput)
        {
            head.transform.localRotation = orientation;
            if (settings.trackPosition)
            {
                head.transform.localPosition = position * settings.trackPositionScale;
            }
        }

    }

	private void OnDestroy()
	{
        //Debug.Log("SvrManager.OnDestroy()");

        StopAllCoroutines();

        UnregisterListeners();

        if (plugin.IsRunning()) plugin.EndVr();
        if (plugin.IsInitialized()) plugin.Shutdown();
    }

    private void OnApplicationPause(bool pause)
	{
        //Debug.Log("SvrManager.OnApplicationPause()");

        SetPause(pause);
	}

	void OnApplicationQuit()
	{
        //Debug.Log("SvrManager.OnApplicationQuit()");

        OnPause();
	}
	
    void RegisterListeners()
    {
        SvrOverrideSettings.OnEyeAntiAliasingChangedEvent += OnEyeAntiAliasingChanged;
        SvrOverrideSettings.OnEyeDepthChangedEvent += OnEyeDepthChanged;
        SvrOverrideSettings.OnEyeResolutionScaleFactorChangedEvent += OnEyeResolutionScaleFactorChanged;
        SvrOverrideSettings.OnOverlayAntiAliasingChangedEvent += OnOverlayAntiAliasingChanged;
        SvrOverrideSettings.OnOverlayDepthChangedEvent += OnOverlayDepthChanged;
        SvrOverrideSettings.OnOverlayResolutionScaleFactorChangedEvent += OnOverlayResolutionScaleFactorChanged;
        SvrOverrideSettings.OnChromaticAberrationCorrectionChangedEvent += OnChromaticAberrationCorrectionChanged;
        SvrOverrideSettings.OnVSyncCountChangedEvent += OnVSyncCountChanged;
        SvrOverrideSettings.OnMasterTextureLimitChangedEvent += OnMasterTextureLimitChanged;
        SvrOverrideSettings.OnPerfLevelChangedEvent += OnPerfLevelChanged;
    }
	
    void UnregisterListeners()
    {
        SvrOverrideSettings.OnEyeAntiAliasingChangedEvent -= OnEyeAntiAliasingChanged;
        SvrOverrideSettings.OnEyeDepthChangedEvent -= OnEyeDepthChanged;
        SvrOverrideSettings.OnEyeResolutionScaleFactorChangedEvent -= OnEyeResolutionScaleFactorChanged;
        SvrOverrideSettings.OnOverlayAntiAliasingChangedEvent -= OnOverlayAntiAliasingChanged;
        SvrOverrideSettings.OnOverlayDepthChangedEvent -= OnOverlayDepthChanged;
        SvrOverrideSettings.OnOverlayResolutionScaleFactorChangedEvent -= OnOverlayResolutionScaleFactorChanged;
        SvrOverrideSettings.OnChromaticAberrationCorrectionChangedEvent -= OnChromaticAberrationCorrectionChanged;
        SvrOverrideSettings.OnVSyncCountChangedEvent -= OnVSyncCountChanged;
        SvrOverrideSettings.OnMasterTextureLimitChangedEvent -= OnMasterTextureLimitChanged;
        SvrOverrideSettings.OnPerfLevelChangedEvent -= OnPerfLevelChanged;
    }
	
    void OnEyeAntiAliasingChanged(SvrOverrideSettings.eAntiAliasing antiAliasing)
    {
        foreach (SvrEye eye in eyes)
        {
            eye.AntiAliasing = antiAliasing == SvrOverrideSettings.eAntiAliasing.NoOverride ? 
                (int)settings.eyeAntiAliasing : (int)antiAliasing;
        }
    }
	
    void OnEyeDepthChanged(SvrOverrideSettings.eDepth depth)
    {
        foreach (SvrEye eye in eyes)
        {
            eye.Depth = depth == SvrOverrideSettings.eDepth.NoOverride ?
                (int)settings.eyeDepth : (int)depth;
        }
    }
	
    void OnEyeResolutionScaleFactorChanged(float scaleFactor)
    {
        foreach (SvrEye eye in eyes)
        {
            eye.ResolutionScaleFactor = scaleFactor <= 0 ? settings.eyeResolutionScaleFactor : scaleFactor;
        }
    }
	
    void OnOverlayAntiAliasingChanged(SvrOverrideSettings.eAntiAliasing antiAliasing)
    {
        foreach (SvrOverlay overlay in overlays)
        {
            overlay.AntiAliasing = antiAliasing == SvrOverrideSettings.eAntiAliasing.NoOverride ?
                (int)settings.overlayAntiAliasing : (int)antiAliasing;
        }
    }
	
    void OnOverlayDepthChanged(SvrOverrideSettings.eDepth depth)
    {
        foreach (SvrOverlay overlay in overlays)
        {
            overlay.Depth = depth == SvrOverrideSettings.eDepth.NoOverride ?
                (int)settings.overlayDepth : (int)depth;
        }
    }
	
    void OnOverlayResolutionScaleFactorChanged(float scaleFactor)
    {
        foreach (SvrOverlay overlay in overlays)
        {
            overlay.ResolutionScaleFactor = scaleFactor <= 0 ? settings.overlayResolutionScaleFactor : scaleFactor;
        }
    }
	
    void OnChromaticAberrationCorrectionChanged(SvrOverrideSettings.eChromaticAberrationCorrection aberrationCorrection)
    {
        if(aberrationCorrection == SvrOverrideSettings.eChromaticAberrationCorrection.kDisable)
        {
            plugin.SetFrameOption(SvrPlugin.FrameOption.kDisableChromaticCorrection);
        }
        else
        {
            plugin.UnsetFrameOption(SvrPlugin.FrameOption.kDisableChromaticCorrection);
        }
    }
	
    void OnVSyncCountChanged(SvrOverrideSettings.eVSyncCount vSyncCount)
    {
        if (vSyncCount == SvrOverrideSettings.eVSyncCount.NoOverride)
        {
            plugin.SetVSyncCount((int)settings.vSyncCount);
            QualitySettings.vSyncCount = (int)settings.vSyncCount;
        }
        else
        {
            plugin.SetVSyncCount((int)vSyncCount);
            QualitySettings.vSyncCount = (int)settings.vSyncCount;
        }
    }
	
    void OnMasterTextureLimitChanged(SvrOverrideSettings.eMasterTextureLimit masterTextureLimit)
    {
        QualitySettings.masterTextureLimit = masterTextureLimit == SvrOverrideSettings.eMasterTextureLimit.NoOverride ? 
            (int)settings.masterTextureLimit : (int)masterTextureLimit;
    }
	
    void OnPerfLevelChanged(SvrOverrideSettings.ePerfLevel cpuPerfLevel, SvrOverrideSettings.ePerfLevel gpuPerfLevel)
    {
        int currentCpuPerfLevel = cpuPerfLevel == SvrOverrideSettings.ePerfLevel.NoOverride ? 
            (int)settings.cpuPerfLevel : (int)SvrOverrideSettings.CpuPerfLevel;
        int currentGpuPerfLevel = gpuPerfLevel == SvrOverrideSettings.ePerfLevel.NoOverride ?
            (int)settings.gpuPerfLevel : (int)SvrOverrideSettings.GpuPerfLevel;
        plugin.SetPerformanceLevels(currentCpuPerfLevel, currentGpuPerfLevel);
    }
	
}