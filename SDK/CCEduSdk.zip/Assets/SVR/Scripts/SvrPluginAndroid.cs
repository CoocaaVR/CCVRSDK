﻿using UnityEngine;
using System;
using System.Collections;
using System.Runtime.InteropServices;

public class SvrPluginAndroid : SvrPlugin
{
	[DllImport("svrplugin")]
	private static extern IntPtr GetRenderEventFunc();

    [DllImport("svrplugin")]
    private static extern bool SvrIsInitialized();

    [DllImport("svrplugin")]
    private static extern bool SvrIsRunning();

    [DllImport("svrplugin")]
    private static extern bool SvrCanBeginVR();

    [DllImport("svrplugin")]
	private static extern void SvrInitializeEventData(IntPtr activity);

	[DllImport("svrplugin")]
	private static extern void SvrSubmitFrameEventData(int frameIndex, float fieldOfView);

    [DllImport("svrplugin")]
    private static extern void SvrSetupLayerCoords(int typeEyeOrOverlay, int layerIndex, float[] lowerLeft, float[] lowerRight, float[] upperLeft, float[] upperRight);
    [DllImport("svrplugin")]
    private static extern void SvrSetupLayerData(int typeEyeOrOverlay, int layerIndex, int sideMask, int textureId, int textureType);

    [DllImport("svrplugin")]
	private static extern void SvrSetTrackingModeEventData(int mode);

	[DllImport("svrplugin")]
	private static extern void SvrSetPerformanceLevelsEventData(int newCpuPerfLevel, 
	                                                            int newGpuPerfLevel);

    [DllImport("svrplugin")]
    private static extern void SvrSetFrameOption(uint frameOption);

    [DllImport("svrplugin")]
    private static extern void SvrUnsetFrameOption(uint frameOption);

    [DllImport("svrplugin")]
    private static extern void SvrSetVSyncCount(int vSyncCount);

    [DllImport("svrplugin")]
	private static extern void SvrGetPredictedPose(ref float rx,
	                                               ref float ry,
	                                               ref float rz,
	                                               ref float rw,
												   ref float px,
												   ref float py,
												   ref float pz,
                                                   int frameIndex);

	[DllImport("svrplugin")]
	private static extern void SvrGetDeviceInfo(ref int displayWidthPixels,
	                                            ref int displayHeightPixels,
	                                            ref float displayRefreshRateHz,
	                                            ref int targetEyeWidthPixels,
	                                            ref int targetEyeHeightPixels,
	                                            ref float targetFovXRad,
	                                       		ref float targetFovYRad);

	private enum RenderEvent
	{
		Initialize,
		BeginVr,
		EndVr,
		EndEye,
		SubmitFrame,
		Shutdown,
		RecenterTracking,
		SetTrackingMode,
		SetPerformanceLevels
	};

	public static SvrPluginAndroid Create()
	{
		if(Application.isEditor)
		{
			Debug.LogError("SvrPlugin not supported in unity editor!");
			throw new InvalidOperationException();
		}

		return new SvrPluginAndroid ();
	}


	private SvrPluginAndroid() {}

	private void IssueEvent(RenderEvent e)
	{
		// Queue a specific callback to be called on the render thread
		GL.IssuePluginEvent(GetRenderEventFunc(), (int)e);
	}

    public override bool IsInitialized() { return SvrIsInitialized(); }

    public override bool IsRunning() { return SvrIsRunning(); }

    public override IEnumerator Initialize()
	{
        //yield return new WaitUntil(() => SvrIsInitialized() == false);  // Wait for shutdown

        yield return base.Initialize();

#if UNITY_ANDROID && !UNITY_EDITOR
		AndroidJavaClass unityPlayer = new AndroidJavaClass("com.unity3d.player.UnityPlayer");
		AndroidJavaObject activity = unityPlayer.GetStatic<AndroidJavaObject>("currentActivity");

		SvrInitializeEventData(activity.GetRawObject());
#endif
        IssueEvent(RenderEvent.Initialize);
		yield return new WaitUntil (() => SvrIsInitialized () == true);

        yield return null;  // delay one frame - fix for re-init w multi-threaded rendering

        deviceInfo = GetDeviceInfo();
    }

	public override IEnumerator BeginVr(int cpuPerfLevel, int gpuPerfLevel)
	{
        //yield return new WaitUntil(() => SvrIsRunning() == false);  // Wait for EndVr

        yield return base.BeginVr(cpuPerfLevel, gpuPerfLevel);

        float[] lowerLeft = { -1f, -1f, 0f, 1f };
        float[] upperLeft = { -1f,  1f, 0f, 1f };
        float[] upperRight = { 1f,  1f, 0f, 1f };
        float[] lowerRight = { 1f, -1f, 0f, 1f };
        SvrSetupLayerCoords(0, -1, lowerLeft, lowerRight, upperLeft, upperRight);    // Eye/All
        SvrSetupLayerCoords(1, -1, lowerLeft, lowerRight, upperLeft, upperRight);    // Overlay/All

        SvrSetPerformanceLevelsEventData(cpuPerfLevel, gpuPerfLevel);

        yield return new WaitUntil(() => SvrCanBeginVR() == true);
        IssueEvent (RenderEvent.BeginVr);
        yield return new WaitUntil(() => SvrIsRunning() == true);
    }

    public override void EndVr()
	{
        base.EndVr();

		IssueEvent (RenderEvent.EndVr);
	}

	public override void EndEye()
	{
		IssueEvent (RenderEvent.EndEye);
	}

    public override void SetTrackingMode(TrackingMode mode)
    {
        SvrSetTrackingModeEventData((int)mode);
		IssueEvent (RenderEvent.SetTrackingMode);
    }

    public override void SetPerformanceLevels(int newCpuPerfLevel, int newGpuPerfLevel)
    {
        SvrSetPerformanceLevelsEventData((int)newCpuPerfLevel, (int)newGpuPerfLevel);
		IssueEvent (RenderEvent.SetPerformanceLevels);
    }

    public override void SetFrameOption(FrameOption frameOption)
    {
        SvrSetFrameOption((uint)frameOption);
    }

    public override void UnsetFrameOption(FrameOption frameOption)
    {
        SvrUnsetFrameOption((uint)frameOption);
    }

    public override void SetVSyncCount(int vSyncCount)
    {
        SvrSetVSyncCount(vSyncCount);
    }

    public override void RecenterTracking()
	{
		IssueEvent (RenderEvent.RecenterTracking);
	}

	public override void GetPredictedPose(ref Quaternion orientation, ref Vector3 position, int frameIndex)
	{
		orientation = Quaternion.identity;
		position = Vector3.zero;

		SvrGetPredictedPose(ref orientation.x, ref orientation.y, ref orientation.z, ref orientation.w,
							ref position.x, ref position.y, ref position.z, frameIndex);

		orientation.z = -orientation.z;
        position.x = -position.x;
        position.y = -position.y;
	}

	public override DeviceInfo GetDeviceInfo()
	{
		DeviceInfo info = new DeviceInfo();

		SvrGetDeviceInfo (ref info.displayWidthPixels,
		                  ref info.displayHeightPixels,
		                  ref info.displayRefreshRateHz,
		                  ref info.targetEyeWidthPixels,
		                  ref info.targetEyeHeightPixels,
		                  ref info.targetFovXRad,
		                  ref info.targetFovYRad);

		return info;
	}

    public override void SubmitFrame(int frameIndex, float fieldOfView)
	{
        int i;
        int eyeCount = 0;
        if (eyes != null) for (i = 0; i < eyes.Length; i++)
        {
            if (eyes[i].isActiveAndEnabled == false || eyes[i].TextureId == 0 || eyes[i].Side == 0) continue;
            if (eyes[i].imageTransform != null && eyes[i].imageTransform.gameObject.activeSelf == false) continue;
            SvrSetupLayerData(0, eyeCount, (int)eyes[i].Side, eyes[i].TextureId, eyes[i].ImageType == SvrEye.eType.EglTexture ? 1 : 0);
            float[] lowerLeft = { eyes[i].clipLowerLeft.x, eyes[i].clipLowerLeft.y, eyes[i].clipLowerLeft.z, eyes[i].clipLowerLeft.w };
            float[] upperLeft = { eyes[i].clipUpperLeft.x, eyes[i].clipUpperLeft.y, eyes[i].clipUpperLeft.z, eyes[i].clipUpperLeft.w };
            float[] upperRight = { eyes[i].clipUpperRight.x, eyes[i].clipUpperRight.y, eyes[i].clipUpperRight.z, eyes[i].clipUpperRight.w };
            float[] lowerRight = { eyes[i].clipLowerRight.x, eyes[i].clipLowerRight.y, eyes[i].clipLowerRight.z, eyes[i].clipLowerRight.w };
            SvrSetupLayerCoords(0, eyeCount, lowerLeft, lowerRight, upperLeft, upperRight);
            eyeCount++;
        }
        for (i = eyeCount; i < SvrManager.EyeLayerMax; i++)
        {
            SvrSetupLayerData(0, i, 0, 0, 0);
        }

        int overlayCount = 0;
        if (overlays != null) for (i = 0; i < overlays.Length; i++)
        {
            if (overlays[i].isActiveAndEnabled == false || overlays[i].TextureId == 0 || overlays[i].Side == 0) continue;
            if (overlays[i].imageTransform != null && overlays[i].imageTransform.gameObject.activeSelf == false) continue;
            SvrSetupLayerData(1, overlayCount, (int)overlays[i].Side, overlays[i].TextureId, overlays[i].ImageType == SvrOverlay.eType.EglTexture ? 1 : 0);
            float[] lowerLeft = { overlays[i].clipLowerLeft.x, overlays[i].clipLowerLeft.y, overlays[i].clipLowerLeft.z, overlays[i].clipLowerLeft.w };
            float[] upperLeft = { overlays[i].clipUpperLeft.x, overlays[i].clipUpperLeft.y, overlays[i].clipUpperLeft.z, overlays[i].clipUpperLeft.w };
            float[] upperRight = { overlays[i].clipUpperRight.x, overlays[i].clipUpperRight.y, overlays[i].clipUpperRight.z, overlays[i].clipUpperRight.w };
            float[] lowerRight = { overlays[i].clipLowerRight.x, overlays[i].clipLowerRight.y, overlays[i].clipLowerRight.z, overlays[i].clipLowerRight.w };
            SvrSetupLayerCoords(1, overlayCount, lowerLeft, lowerRight, upperLeft, upperRight); overlayCount++;
        }
        for (i = overlayCount; i < SvrManager.OverlayLayerMax; i++)
        {
            SvrSetupLayerData(1, i, 0, 0, 0);
        }

        SvrSubmitFrameEventData(frameIndex, fieldOfView);
		IssueEvent (RenderEvent.SubmitFrame);
	}

	public override void Shutdown()
	{
        IssueEvent (RenderEvent.Shutdown);

        base.Shutdown();
	}

}

