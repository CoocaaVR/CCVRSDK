﻿using UnityEngine;
using System;
using System.Collections;

public abstract class SvrPlugin
{
	private static SvrPlugin instance;

	public static SvrPlugin Instance
	{
		get
		{
			if (instance == null)
			{
				if(!Application.isEditor && Application.platform == RuntimePlatform.Android)
				{
					instance = SvrPluginAndroid.Create();
				}
				else
				{
					instance = SvrPluginWin.Create();
				}
			}
			return instance;
		}
	}

    public SvrManager svrCamera = null;
    public SvrEye[] eyes = null;
    public SvrOverlay[] overlays = null;
    public DeviceInfo deviceInfo;

    public enum PerfLevel
	{
        kPerfSystem = 0,
        kPerfMaximum = 1,
		kPerfNormal = 2,
		kPerfMinimum = 3
	}

    public enum TrackingMode
    {
        kTrackingOrientation = 1,
        kTrackingPosition = 2
    }

    public enum FrameOption
    {
        kDisableDistortionCorrection = (1 << 0),   //!< Disables the lens distortion correction (useful for debugging)
        kDisableReprojection = (1 << 1),   //!< Disables re-projection
        kEnableMotionToPhoton = (1 << 2),   //!< Enables motion to photon testing 
        kDisableChromaticCorrection = (1 << 3)   //!< Disables the lens chromatic aberration correction (performance optimization)
    };

    public struct DeviceInfo
	{
		public int 		displayWidthPixels;
		public int    	displayHeightPixels;
		public float  	displayRefreshRateHz;
		public int    	targetEyeWidthPixels;
		public int    	targetEyeHeightPixels;
		public float  	targetFovXRad;
		public float  	targetFovYRad;
	}

    public virtual bool IsInitialized() { return false; }
    public virtual bool IsRunning() { return false; }
    public virtual IEnumerator Initialize ()
    {
        var go = GameObject.FindGameObjectWithTag("SvrCamera");
        if (go == null)
        {
            Debug.Log("Gameobject with tag SvrCamera not found!");
            yield break;
        }
        svrCamera = go.GetComponent<SvrManager>();
        if (svrCamera == null)
        {
            Debug.Log("SvrManager not found!");
            yield break;
        }

        yield break;
    }
	public virtual IEnumerator BeginVr(int cpuPerfLevel =0, int gpuPerfLevel =0)
    {
        if (eyes == null)
        {
            eyes = svrCamera.gameObject.GetComponentsInChildren<SvrEye>();
            if (eyes == null)
            {
                Debug.Log("Components with SvrEye not found!");
            }

            Array.Sort(eyes);
        }

        if (overlays == null)
        {
            overlays = svrCamera.gameObject.GetComponentsInChildren<SvrOverlay>();
            if (overlays == null)
            {
                Debug.Log("Components with SvrOverlay not found!");
            }

            Array.Sort(overlays);
        }

        yield break;
    }
    public virtual void EndVr()
    {
        eyes = null;
        overlays = null;
    }
    public virtual void EndEye() { }
    public virtual void SetTrackingMode(TrackingMode mode) { }
    public virtual void SetPerformanceLevels(int newCpuPerfLevel, int newGpuPerfLevel) { }
    public virtual void SetFrameOption(FrameOption frameOption) { }
    public virtual void UnsetFrameOption(FrameOption frameOption) { }
    public virtual void SetVSyncCount(int vSyncCount) { }
    public virtual void RecenterTracking() { }
    public virtual void SubmitFrame(int frameIndex, float fieldOfView) { }
	public virtual void GetPredictedPose (ref Quaternion orientation, ref Vector3 position, int frameIndex = -1)
	{
		orientation =  Quaternion.identity;
		position = Vector3.zero;
	}
	public abstract DeviceInfo GetDeviceInfo ();
	public virtual void Shutdown()
    {
        SvrPlugin.instance = null;
    }
}

