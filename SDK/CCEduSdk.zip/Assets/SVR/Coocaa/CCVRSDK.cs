﻿
public class CCVRSDK  {
	public const string version = "1.1.4.170420";
}
