﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Events;
using UnityEngine.EventSystems;
using System.Runtime.InteropServices;
using CC;

public class CCHotPoniterSettings : MonoBehaviour, IPointerEnterHandler,IPointerExitHandler,IPointerClickHandler{

    public delegate void HotPointerClicked(CCHotPoniterSettings hotPoint);
    public HotPointerClicked hotPointerClicked;

    public int hp_id;
	public string hp_name;
	public string hp_desp;
	public GameObject title;
	public GameObject content;
	public bool isPlayMode = false;
	private GameObject allContent;
	private CCHPTargetController hpTarget;
	private Animator animator;
	// Use this for initialization

	void Start () {
		isPlayMode = true;
		allContent = this.transform.Find ("AllContent").gameObject;
		hpTarget = this.transform.Find ("CCHPTarget").GetComponent<CCHPTargetController>();
		animator = this.GetComponent<Animator> ();
		content.GetComponent<Text> ().text = hp_desp;
		title.GetComponent<Text> ().text = hp_name;
		Debug.Log ("nox ---- hpid " + hp_id + "hp_des:" + content.GetComponent<Text>().text + "  hp_name:" + hp_name);
		print ("CC:"+CCLog.add (10,10));
	}



	void OnEable(){
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	public void OnPointerEnter (PointerEventData eventData){
		
		allContent.SetActive(true);
		hpTarget.SetFocusState (1);
		animator.SetInteger ("isShow", 1);
		float detailHeight = content.GetComponent<Text>().preferredHeight;
		float contentHeight = 54f + (detailHeight >= 72f ? detailHeight : 72f) + 16f;
		contentHeight = contentHeight <= 358f ? contentHeight : 358f;
		SetRectTransformSize (allContent.GetComponent<RectTransform> (), new Vector2 (allContent.GetComponent<RectTransform> ().sizeDelta.x, contentHeight));
	}

	public void OnPointerExit (PointerEventData eventData){
		allContent.SetActive(false);
		hpTarget.SetFocusState (-1);
		animator.SetInteger ("isShow", 2);
	}

	public void OnPointerClick (PointerEventData eventData){
		//TODO:传给controller自己的id，点击保护1s

        if (hotPointerClicked != null)
        {
            hotPointerClicked(this);
        }
	}

	/**
	 * 设置 UI RectTransform 大小
	 */ 
	public static void SetRectTransformSize (RectTransform trans, Vector2 newSize)
	{
		Vector2 oldSize = trans.rect.size;
		Vector2 deltaSize = newSize - oldSize;
		trans.offsetMin = trans.offsetMin - new Vector2 (deltaSize.x * trans.pivot.x, deltaSize.y * trans.pivot.y);
		trans.offsetMax = trans.offsetMax + new Vector2 (deltaSize.x * (1f - trans.pivot.x), deltaSize.y * (1f - trans.pivot.y));
	}
}
