﻿/*
 * 使用方法
 * 
 * HostWindow.SendWindowMsg("字符串", WindowName);
 * 
*/
using System;
using UnityEngine;
using System.Collections;
using System.Runtime.InteropServices;
using System.Text;

public class HostWindow
{
    //发送小心的窗口 
    private static IntPtr m_hWnd;

    private const int WM_COPYDATA = 0x004A;

    /// <summary>  
    /// 发送windows消息方便user32.dll中的SendMessage函数使用  
    /// </summary>  
    [StructLayout(LayoutKind.Sequential)]
    private struct COPYDATASTRUCT
    {
        public IntPtr dwData;    //用户定义数据
        public int cbData;       //用户数据长度
        [MarshalAs(UnmanagedType.LPStr)]
        public string lpData;
    }

    //user32.dll中的SendMessage  
    [DllImport("user32.dll")]
    private static extern IntPtr SendMessage(
        IntPtr hWnd,        //要hook的window
        int Msg,            //消息
        int wParam,         
        ref COPYDATASTRUCT lParam 
        );

    //user32.dll中的获得窗体句柄  
    [DllImport("user32.dll")]
    private static extern IntPtr FindWindow(string strClassName, string strWindowName);


    //发送消息
    public static void SendWindowMsg(string msg, string wndName )
    {
        string data = msg;
        COPYDATASTRUCT cds = new COPYDATASTRUCT();
        cds.lpData = data;
        cds.dwData = (IntPtr)901;
        cds.cbData = data.Length + 1;

        m_hWnd = FindWindow(null, wndName);
        SendMessage(m_hWnd, WM_COPYDATA, 0, ref cds);
    }

}