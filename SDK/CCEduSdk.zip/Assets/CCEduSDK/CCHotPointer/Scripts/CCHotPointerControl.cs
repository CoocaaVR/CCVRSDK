﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CCHotPointerControl : MonoBehaviour {

	public static CCHotPointerControl mInstance = null;

    public List<CCHotPoniterSettings> hotPointerList;
    private List<CCHotPoniterSettings> OrderlyHotPointerList;

    private int currentHotIndex = -1;

	// Use this for initialization
	void Start () {
		mInstance = this;

        InitClickedEvent();
	}

    void Update ()
    {
        //按下事件  
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            Debug.Log("您按下了Escape键");
            //TODO:返回上一个场景
        }
        else if(Input.GetKeyDown(KeyCode.UpArrow))
        {
            //下一个热点
            GoToPreHotPoint();
        }
        else if (Input.GetKeyDown(KeyCode.DownArrow))
        {
            //上一个热点
            GoToNextHotPoint();
        }
    }

	private void InitClickedEvent()
    {
        OrderlyHotPointerList = new List<CCHotPoniterSettings>(hotPointerList);
        //按id排序
        OrderlyHotPointerList.Sort(delegate (CCHotPoniterSettings x, CCHotPoniterSettings y)
        {
            return x.hp_id.CompareTo(y.hp_id);
        });

        //注册事件处理
        foreach (CCHotPoniterSettings item in OrderlyHotPointerList)
        {            
            item.hotPointerClicked = HotPointerClickedByPC;
        }
    }

    private int GetIndexByHotPointerId(int id)
    {
        int index = -1;

        for (int i = 0; i < OrderlyHotPointerList.Count; i++)
        {
            CCHotPoniterSettings item = OrderlyHotPointerList[i];
            if (item.hp_id == id)
            {
                index = i;
                break;
            }
        }

        return index;
    }

    /// <summary>
    /// 跳转到上一个热点，如果当前没有选中热点，则跳转到第0个热点
    /// </summary>
    public void GoToPreHotPoint()
    {
        if (currentHotIndex == 0)
        {
            Debug.Log("碰顶啦，已经是第一个热点，本次事件不作处理");
            return;
        }
        --currentHotIndex;
        currentHotIndex = currentHotIndex <= 0 ? 0 : currentHotIndex;
        if (currentHotIndex < OrderlyHotPointerList.Count)
        {
            CCHotPoniterSettings hotPointer = OrderlyHotPointerList[currentHotIndex];
            if (hotPointer != null)
            {
                HotPointerClickedByPC(hotPointer);
            }
        }

    }

    /// <summary>
    /// 跳转到下一个热点,如果当前没有选中热点，则跳转到第0个热点
    /// </summary>
    public void GoToNextHotPoint()
    {
        ++currentHotIndex;
        if (currentHotIndex >= OrderlyHotPointerList.Count)
        {
            currentHotIndex = OrderlyHotPointerList.Count - 1;
            Debug.Log("撞墙啦，已到最后一个热点，本次事件不作处理");
            return;
        }
        currentHotIndex = currentHotIndex <= 0 ? 0 : currentHotIndex;

        if (currentHotIndex < OrderlyHotPointerList.Count)
        {
            CCHotPoniterSettings hotPointer = OrderlyHotPointerList[currentHotIndex];
            if (hotPointer != null)
            {
                HotPointerClickedByPC(hotPointer);
            }
        }
    }

    /// <summary>
    /// PC端收到点击事件，需要把事件传给中控平台
    /// </summary>
    /// <param name="hotPoint"></param>
    private void HotPointerClickedByPC(CCHotPoniterSettings hotPoint)
    {
		Debug.Log(">>> Hot pointer " + hotPoint.hp_id + " " + hotPoint.hp_name + " clicked!");
		currentHotIndex = GetIndexByHotPointerId(hotPoint.hp_id);

		//通知中控端，转发热点事件给VR端
		JSONObject jobj = new JSONObject();
		jobj.Add ("cmd", "CMD_CLICK_HOTPOINT");
		jobj.Add ("params", hotPoint.hp_id+"");
		HostWindow.SendWindowMsg(jobj.ToString (), CCEduApi.CCEDU_CENTER_PRODUCT_NAME);
    }
    

    /// <summary>
    /// VR端收到点击事件，需要做相应的处理
    /// </summary>
    /// <param name="pointId"></param>
    public void HotPointerClickedByVR(int pointId)
    {
    }

}
