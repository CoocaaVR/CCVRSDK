﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;

public class CCHPTargetController : MonoBehaviour {

	public Texture[] FocusTextures;
	public Texture[] StayTextures;
	public RawImage Target;
	//-1:exit, 0:noting, 1:enter
	private int focusState = 0;
	private bool isStay = false;
	private int focusIndex = 0;
	private int stayIndex = 0;
	// Use this for initialization
	void Start () {
		
	}

	void FixedUpdate(){
		if (focusState == 1) {
			if (focusIndex < FocusTextures.Length) {
				Target.texture = FocusTextures[focusIndex];
				focusIndex++;
			}
		} else if (focusState == -1) {
			if (focusIndex >= 0) {
				Target.texture = FocusTextures[focusIndex];
				focusIndex--;
			}
		} 

		if (isStay == true) {

			if (stayIndex == StayTextures.Length) {
				stayIndex = 0;
			}

			if (stayIndex >= 0 && stayIndex < StayTextures.Length) {
				Target.texture = StayTextures [stayIndex];
				stayIndex++;
			}
		}
	}

	// Update is called once per frame
	void Update () {
		
	}

	public void SetFocusState(int state){
		focusState = state;
		if (focusState == 1) {
			focusIndex = 0;
			Invoke ("targetStay", 1f);
		} else if (focusState == -1) {
			focusIndex = FocusTextures.Length - 1;
			CancelInvoke ();
			isStay = false;
			stayIndex = 0;
		} else {
			//回归
			focusIndex = 0;
		}
	}

	private void targetStay(){
		isStay = true;
	}

}
