﻿/*
 * 
 * 使用说明:
 * 
 * 在需要接收消息的类中，分别实现以下方法
 * 
 * private void OnEnable()
    {
        ClientWindow.StartListening();
        ClientWindow.OnClientWindowReceiveEvent += ReceiveMessage;
    }

    private void OnDestroy()
    {
        ClientWindow.StopListening();
        ClientWindow.OnClientWindowReceiveEvent -= ReceiveMessage;
    }

    private void ReceiveMessage(string msg)
    {
        Debug.Log("Receive message :" + msg);
    }
 * 
 * 
 */

using UnityEngine;
using System;
using System.Text;
using System.Diagnostics;
using System.Runtime.InteropServices;
using Debug = UnityEngine.Debug;


public class ClientWindow
{
    //钩子类型 全局钩子 
    private const int WH_CALLWNDPROC = 4;
    //消息类型 
    private const int WM_COPYDATA = 0x004A;  
    //钩子  
    private static int idHook = 0;
    //是否安装了钩子  
    private static bool isHook = false;
    private static GCHandle gc;
    private static bool _bCallNext;

    public delegate void ClientWindowReceiveEventHandler(string msg);
    public static event ClientWindowReceiveEventHandler OnClientWindowReceiveEvent;

    //建立钩子  
    [DllImport("user32.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.StdCall)]
    private static extern int SetWindowsHookEx(int idHook, HookProc lpfn, IntPtr hInstance, uint dwThreadId);

    //移除钩子  
    [DllImport("user32.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.StdCall)]
    private static extern bool UnhookWindowsHookEx(int idHook);

    //把信息传递到下一个监听  
    [DllImport("user32.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.StdCall)]
    private static extern int CallNextHookEx(int idHook, int nCode, int wParam, int lParam);

    //回调委托  
    private delegate int HookProc(int nCode, int wParam, int lParam);

    //钩子接收消息的结构  
    [StructLayout(LayoutKind.Sequential)]
    private struct CWPSTRUCT
    {
        public int lparam;
        public int wparam;
        public uint message;
        public IntPtr hwnd;
    }

    private struct COPYDATASTRUCT
    {
        public IntPtr dwData;
        public int cbData;
        [MarshalAs(UnmanagedType.LPStr)]
        public string lpData;
    }

    private static bool CallNextProc
    {
        get { return _bCallNext; }
        set { _bCallNext = value; }
    }

    public static void StartListening()
    {
        //安装钩子  
        HookLoad();
    }

    public static void StopListening()
    {
        //关闭钩子  
        HookClosing();
    }


    private static void HookLoad()
    {
        //钩子委托  
        HookProc lpfn = new HookProc(Hook);

        //关联进程的主模块  
        IntPtr hInstance = IntPtr.Zero;
        idHook = SetWindowsHookEx(WH_CALLWNDPROC, lpfn, hInstance, (uint)AppDomain.GetCurrentThreadId());
        if (idHook > 0)
        {
            Debug.Log("钩子[" + idHook + "]安装成功");
            isHook = true;
            //保持活动 避免 回调过程 被垃圾回收  
            gc = GCHandle.Alloc(lpfn);
        }
        else
        {
            Debug.Log("钩子安装失败");
            isHook = false;
            UnhookWindowsHookEx(idHook);
        }
    }


    //卸载钩子  
    private static void HookClosing()
    {
        if (isHook)
        {
            UnhookWindowsHookEx(idHook);
        }
    }

    //钩子回调  
    private static int Hook(int nCode, int wParam, int lParam)
    {
        try
        {
            IntPtr p = new IntPtr(lParam);
            CWPSTRUCT m = (CWPSTRUCT)Marshal.PtrToStructure(p, typeof(CWPSTRUCT));

            if (m.message == WM_COPYDATA)
            {
                COPYDATASTRUCT entries = (COPYDATASTRUCT)Marshal.PtrToStructure((IntPtr)m.lparam, typeof(COPYDATASTRUCT));

                byte[] bt = new byte[entries.cbData];
                IntPtr ptr = Marshal.StringToHGlobalAnsi(entries.lpData);
                Marshal.Copy(ptr, bt, 0, bt.Length);
                string str = Encoding.Default.GetString(bt);

                Debug.Log("---------收到消息：" + str);
                if (OnClientWindowReceiveEvent != null)
                {
                    OnClientWindowReceiveEvent(str);
                }
            }
            if (CallNextProc)
            {
                return CallNextHookEx(idHook, nCode, wParam, lParam);
            }
            else
            {
                //return 1;  
                return CallNextHookEx(idHook, nCode, wParam, lParam);
            }
        }
        catch (Exception ex)
        {
            Debug.Log(ex.Message);
            return 0;
        }

    }

}