﻿using UnityEngine;
using System.Collections.Generic;
using UnityEngine.UI;

#if UNITY_EDITOR

using UnityEditor;
using UnityEditor.UI;



[ExecuteInEditMode]
[CustomEditor(typeof(CCHotPointerControl))]
public class CCHotPointerControlEditor : Editor
{
    private CCHotPointerControl myTarget;
    private bool showWeapons;
    private bool shouldOrder = false;
    void OnEnable()
    {
        //获取当前编辑自定义Inspector的对象  
        myTarget = (CCHotPointerControl)target;
    }


    public override void OnInspectorGUI()
    {
        GameObject[] lists = GameObject.FindGameObjectsWithTag("HotPointer");
        myTarget.hotPointerList = new List<CCHotPoniterSettings>();

        for (int i = 0; i < lists.Length; i++)
        {
            CCHotPoniterSettings item = lists[i].GetComponent<CCHotPoniterSettings>();
            if (item != null)
            {
                myTarget.hotPointerList.Add(item);
            }
        }


        //热点按id升序排序
        if (shouldOrder)
        {
            myTarget.hotPointerList.Sort(delegate (CCHotPoniterSettings x, CCHotPoniterSettings y)
            {
                return x.hp_id.CompareTo(y.hp_id);
            });
        } 

        EditorGUIUtility.labelWidth = 65;
        GUILayout.Space(10);
        GUI.skin.label.fontSize = 16;
        GUI.skin.label.fontStyle = FontStyle.Normal;
        GUI.skin.label.alignment = TextAnchor.MiddleCenter;
        GUILayout.Label("热点管理");

        GUILayout.Space(10);
        for (int i = 0; i < lists.Length; i++)
        {
            CCHotPoniterSettings item =myTarget.hotPointerList[i];
            if (item != null)
            {
                GUILayout.BeginHorizontal();

                GUI.skin.label.fontSize = 10;
                GUI.skin.label.alignment = TextAnchor.MiddleLeft;
                EditorGUILayout.LabelField("热点名称:" + item.hp_name, GUILayout.MaxWidth(200));

                item.hp_id = EditorGUILayout.IntField("排序:", item.hp_id, new GUILayoutOption[] {
                    GUILayout.Width(100),
                });
                EditorUtility.SetDirty(item);

                GUILayout.EndHorizontal();

                int flag = 0;
                foreach(CCHotPoniterSettings hot in myTarget.hotPointerList)
                {
                    if (hot.hp_id == item.hp_id)
                    {
                        flag++;
                        if (flag == 2)
                        {
                            break;
                        }
                    }
                }

                if (myTarget.isActiveAndEnabled == true && flag == 2)
                {
                    EditorGUILayout.HelpBox("排序id不能相同", MessageType.Error);
                }

            }

        GUILayout.Space(5);
        }


        if (GUILayout.Button("排序"))
        {
            Debug.Log("开始排序");
            shouldOrder = true;
            GUI.FocusControl("排序");
        }

        ////update target info
        if (GUI.changed)
        {
            EditorUtility.SetDirty(myTarget);
        }
    }

}

#endif