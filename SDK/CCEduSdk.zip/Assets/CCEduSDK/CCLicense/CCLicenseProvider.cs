﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CCLicenseProvider {
	
	private const string numChar = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";

	/// <summary>
	/// 随机获取key
	/// </summary>
	/// <returns>The license key.</returns>
	public static string GetLicenseKey()
	{
		string keys = "";
		for (int i = 0; i < 16; i++) {
			keys += numChar.Substring (Random.Range (0, 61), 1);
		}

		Debug.Log ("keys: " + keys);
		return keys;

	}

	/// <summary>
	/// 获取加密密文
	/// </summary>
	/// <returns>返回加密后的密文.</returns>
	/// <param name="originStr">加密明文</param>
	/// <param name="licenseKey">License key.</param>
	public static string GetLicenseString(string originStr,string licenseKey)
	{
		string license = CCLicenseEncrypt.Encrypt(originStr, licenseKey);
		return license;
	}

	/// <summary>
	/// 获取加密的明文
	/// </summary>
	/// <returns>返回明文</returns>
	/// <param name="decryptString">加密密文</param>
	/// <param name="decryptKey">License key.</param>
	public static string GetOriginString(string decryptString, string decryptKey)
	{
		string outLicense = CCLicenseEncrypt.Decrypt(decryptString,decryptKey);
		return outLicense;

	}
}
