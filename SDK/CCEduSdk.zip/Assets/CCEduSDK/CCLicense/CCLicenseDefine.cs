﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CCLicenseDefine  {

	public static string LICENSE_FILE_PATH = "/sdcard/License/";

	public static string LICENSE_FILE_NAME = "license.xml";

	public static string LICENSE_KEY= "key";

	public static string LICENSE_VALUE = "license";

	public static string ATTRIBUTE = "value";

	public static byte[] SALT_BYTES = { 0x01, 0x10, 0x02, 0x20, 0x50, 0xAB, 0x30, 0xEF, 0x12 };

	public static byte[] IV_BYTES = { 0x12, 0x34, 0x56, 0x78, 0x90, 0xAB, 0xCD, 0xEF, 0x21, 0x43, 0x65, 0x87, 0x09, 0xAB, 0xCD, 0xEF };

}