﻿using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Xml;
using UnityEngine;

public class CCLicense {

	/// <summary>
	/// 验证APP是否授权某台设备
	/// </summary>
	public static void ValidAppLicense()
	{
		Debug.Log ("-------------The licenseKey");
		string licenseKey = LoadLicenseKey ();
		if (string.IsNullOrEmpty (licenseKey)) 
		{
			Debug.Log ("-------------The licenseKey can not found!");
			Application.Quit ();
			return;
		}

		List<string> licList = LoadLicenseList ();

		if (licList.Count == 0)
		{
			Debug.Log ("-------------The license is empty!");
			Application.Quit ();
			return;
		}
		string currentLic = GetCurrentLicense (licenseKey);


		if (!licList.Contains (currentLic) || licList.Count == 0) {
			Debug.Log ("-------------The device is not support open lesson!");
			Application.Quit ();
			return;
		}

	}
		

	/// <summary>
	/// 获取当前的加密串
	/// </summary>
	/// <returns>The current encrypt key.</returns>
	private static string GetCurrentLicense(string licKey)
	{
		string macStr = CCSystemApi.getMacAddress ();
		string license = CCLicenseProvider.GetLicenseString (macStr, licKey);
		return license;
	}

	/// <summary>
	/// 获取授权key
	/// </summary>
	/// <returns>The license key.</returns>
	private static string LoadLicenseKey()
	{
		string licenseKey = "";

		//如果不存在配置文件，返回false
		if (!File.Exists (CCLicenseDefine.LICENSE_FILE_PATH + CCLicenseDefine.LICENSE_FILE_NAME)) {
			Debug.Log ("-------------The encrypt file " + CCLicenseDefine.LICENSE_FILE_PATH + CCLicenseDefine.LICENSE_FILE_NAME + " is not exist!");
			return licenseKey;
		}

		string xmlPath = CCLicenseDefine.LICENSE_FILE_PATH + CCLicenseDefine.LICENSE_FILE_NAME;

		//读取配置
		try{
			XmlDocument xmlDoc = new XmlDocument ();
			xmlDoc.Load (xmlPath);
			XmlElement rootElem = xmlDoc.DocumentElement;
			XmlNodeList nodeList = rootElem.GetElementsByTagName (CCLicenseDefine.LICENSE_KEY);
			foreach (XmlNode node in nodeList) {
				string key = ((XmlElement)node).GetAttribute (CCLicenseDefine.ATTRIBUTE);
				Debug.Log ("---------++++++++Key is: " + key);

				if (!string.IsNullOrEmpty (key)) {
					licenseKey = key;
				}
			}
		}catch(System.Exception ex) {
			Debug.Log ("------XML Exceotion: " + ex.Message);
		}

		return licenseKey;
	}


	/// <summary>
	/// 获取授权License数组
	/// </summary>
	/// <returns>The valid config.</returns>
	private static List<string> LoadLicenseList()
	{
		List<string> secretKeys = new List<string>();

		//如果不存在配置文件，返回false
		if (!File.Exists (CCLicenseDefine.LICENSE_FILE_PATH + CCLicenseDefine.LICENSE_FILE_NAME)) {
			Debug.Log ("-------------The encrypt file " + CCLicenseDefine.LICENSE_FILE_PATH + CCLicenseDefine.LICENSE_FILE_NAME + " is not exist!");
			return secretKeys;
		}

		string xmlPath = CCLicenseDefine.LICENSE_FILE_PATH + CCLicenseDefine.LICENSE_FILE_NAME;

		//读取配置
		try{
			XmlDocument xmlDoc = new XmlDocument ();
			xmlDoc.Load (xmlPath);
			XmlElement rootElem = xmlDoc.DocumentElement;
			XmlNodeList nodeList = rootElem.GetElementsByTagName (CCLicenseDefine.LICENSE_VALUE);
			foreach (XmlNode node in nodeList) {
				string license = ((XmlElement)node).GetAttribute (CCLicenseDefine.ATTRIBUTE);
				Debug.Log ("------------License is: " + license);

				if (!string.IsNullOrEmpty (license)) {
					secretKeys.Add (license);
				}
			}
		}catch(System.Exception ex) {
			Debug.Log ("------XML Exceotion: " + ex.Message);
		}

		return secretKeys;
	}
}
