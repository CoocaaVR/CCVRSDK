using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using UnityEngine.Networking.NetworkSystem;
using CC.libuv;

public class CCEduApi : MonoBehaviour {

	public static CCEduApi mInstance = null;

	public const string CCEDU_CENTER_PRODUCT_NAME = "CoocaaEdu";
	public SvrManager svrManager;
	public GameObject hotPoints;

	void Awake(){
		
		mInstance = this;

		initPlatform ();
	}

	private void initPlatform(){
		#if UNITY_ANDROID && !UNITY_EDITOR
		svrManager.gameObject.SetActive(true);
		hotPoints.SetActive(false);

		// 注册监听VR端service的命令
		CCPlatformBridge.getInstance ();
		CCPlatformBridge.OnMessageEvent += OnReceiveVrMessage;
		#endif

		#if UNITY_STANDALONE_WIN || UNITY_EDITOR
		ClientWindow.StartListening();
		ClientWindow.OnClientWindowReceiveEvent += OnReceivePcMessage;
		#endif
	}

	/// <summary>
	/// VR端接受中控端发来的命令
	/// </summary>
	/// <param name="cmd">Cmd.</param>
	/// <param name="_params">Parameters.</param>
	private void OnReceiveVrMessage (string cmd, JSONObject _params) {
		switch (cmd) {
		case CmdDef.CMD_HOT_POINT:
			int id = int.Parse (_params.getString ("hotPoint"));
			Debug.Log("<<< receive Hot pointer " + id + " clicked!");
			if (CCHotPointerControl.mInstance != null) {
				CCHotPointerControl.mInstance.HotPointerClickedByVR (id);
			}
			break;
		default:
			break;
		}
	}

	/// <summary>
	/// PC端接受到中控平台的命令
	/// </summary>
	/// <param name="msg">Message.</param>
	private void OnReceivePcMessage(string msg) {
		Debug.Log("dvlee >>> Receive message :" + msg);
	}

	void OnApplicationQuit() {
		#if UNITY_ANDROID && !UNITY_EDITOR
		CCPlatformBridge.OnMessageEvent -= OnReceiveVrMessage;
		CCPlatformBridge.getInstance ().CleanUp ();
		#endif

		#if UNITY_STANDALONE_WIN || UNITY_EDITOR
		ClientWindow.StopListening();
		ClientWindow.OnClientWindowReceiveEvent -= OnReceivePcMessage;

		JSONObject jobj = new JSONObject();
		jobj.Add ("cmd", "CMD_EXE_CLOSE");
		jobj.Add ("params", "");
		HostWindow.SendWindowMsg(jobj.ToString (), CCEDU_CENTER_PRODUCT_NAME);
		#endif
	}
}
