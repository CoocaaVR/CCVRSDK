﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

#if UNITY_EDITOR

using UnityEditor;
using UnityEditor.UI;



[ExecuteInEditMode]
[CustomEditor(typeof(CCHotPoniterSettings))]
public class CCHotPoniterSettingsEditor : Editor {
	

	public override void OnInspectorGUI() {
		CCHotPoniterSettings myTarget = (CCHotPoniterSettings)target;
		GameObject[] lists = GameObject.FindGameObjectsWithTag("HotPointer");

//		if (myTarget.isActiveAndEnabled == true && myTarget.hp_id == 0 && myTarget.isPlayMode == false) {
//			Debug.Log ("nox --"+myTarget.name+"-- new value, target old id:"+myTarget.hp_id + "and is runinplay:" + myTarget.isPlayMode );
//
//			myTarget.hp_id = lists.Length;
//		}

		if (myTarget.isActiveAndEnabled == false) {
			Debug.Log ("nox --- active false");
			myTarget.hp_id = 0;
		}


		EditorGUIUtility.labelWidth = 65;

		GUILayout.Space(10);
		GUI.skin.label.fontSize = 16;
		GUI.skin.label.fontStyle = FontStyle.Normal;
		GUI.skin.label.alignment = TextAnchor.MiddleCenter;
		GUILayout.Label("热点属性");

		GUILayout.Space(10);
		GUI.skin.label.fontSize = 14;
		GUI.skin.textArea.wordWrap = true;

		GUILayout.Label ("id: " + myTarget.hp_id.ToString ());
//		EditorGUILayout.LabelField ("id: " + myTarget.initId.ToString(),GUILayout.MinWidth(EditorGUIUtility.currentViewWidth));
		GUILayout.Space(5);

		GUIStyle guiStyle = EditorStyles.textArea;
		guiStyle.wordWrap = true;
		GUILayout.BeginHorizontal ();
		GUI.skin.label.fontSize = 10;
		GUI.skin.label.alignment = TextAnchor.MiddleLeft;
		GUILayout.Label("名称:",GUILayout.MaxWidth(60));

		myTarget.hp_name = EditorGUILayout.TextArea(myTarget.hp_name, guiStyle, new GUILayoutOption[]
			{
				GUILayout.Height(20f),
				GUILayout.Width(EditorGUIUtility.currentViewWidth - 85),
			});
		
		if (myTarget.isActiveAndEnabled == true && myTarget.hp_name.Length == 0) {
			EditorGUILayout.HelpBox ("名称不可为空", MessageType.Error);
		}
		GUILayout.EndHorizontal ();

		GUILayout.Space(5);


		GUILayout.BeginHorizontal ();

		GUI.skin.label.fontSize = 10;
		GUI.skin.label.alignment = TextAnchor.MiddleLeft;
		GUILayout.Label("描述:",GUILayout.MaxWidth(60));

		myTarget.hp_desp = EditorGUILayout.TextArea(myTarget.hp_desp, guiStyle, new GUILayoutOption[]
			{
				GUILayout.Height(100f),
				GUILayout.Width(EditorGUIUtility.currentViewWidth - 85),
			});

		GUILayout.EndHorizontal ();

	
		GUILayout.Space (15);

		GUIStyle alertStyle = EditorStyles.label;
		alertStyle.richText = true;
		GUI.skin.label.alignment = TextAnchor.MiddleCenter;
		GUILayout.Label("<color=red>固定参数，请勿修改</color>",alertStyle);

		myTarget.title = EditorGUILayout.ObjectField ("title",myTarget.title,typeof(GameObject),true) as GameObject;
		myTarget.content = EditorGUILayout.ObjectField ("content",myTarget.content,typeof(GameObject),true) as GameObject;

		GUILayout.Space (15);

		if (myTarget.isActiveAndEnabled == true && myTarget.title != null) {
			Text title = myTarget.title.GetComponent<Text> ();
			if (title != null && myTarget.hp_name != null) {
				title.text = myTarget.hp_name;
			}

			Text content = myTarget.content.GetComponent<Text>();
			if (content != null && myTarget.hp_desp != null) {
				content.text = myTarget.hp_desp;
			}
		}

		//update target info
		if (GUI.changed)
			EditorUtility.SetDirty(myTarget);

	}

}

#endif


